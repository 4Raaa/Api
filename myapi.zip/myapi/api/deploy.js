import formidable from "formidable";
import fs from "fs";
import fetch from "node-fetch";

export const config = {
  api: {
    bodyParser: false
  }
};

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const form = formidable({ multiples: true });

  form.parse(req, async (err, fields, files) => {
    if (err) {
      return res.status(500).json({ error: "Upload error" });
    }

    const token = fields.token;

    if (!token) {
      return res.status(400).json({ error: "Token kosong" });
    }

    let fileArray = Array.isArray(files.files)
      ? files.files
      : [files.files];

    let vercelFiles = [];

    for (let file of fileArray) {
      const content = fs.readFileSync(file.filepath).toString("base64");

      vercelFiles.push({
        file: file.originalFilename,
        data: content,
        encoding: "base64"
      });
    }

    try {
      const response = await fetch("https://api.vercel.com/v13/deployments", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: "auto-deploy",
          files: vercelFiles,
          projectSettings: {
            framework: null
          }
        })
      });

      const result = await response.json();

      if (result.url) {
        return res.json({
          success: true,
          url: "https://" + result.url
        });
      } else {
        return res.status(500).json(result);
      }

    } catch (e) {
      return res.status(500).json({ error: e.message });
    }
  });
}