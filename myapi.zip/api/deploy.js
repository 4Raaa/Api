import formidable from "formidable";
import fetch from "node-fetch";
import AdmZip from "adm-zip";

export const config = {
  api: { bodyParser: false }
};

export default async function handler(req, res) {
  if (req.method !== "POST") {
    return res.status(405).json({ error: "Method not allowed" });
  }

  const form = formidable();

  form.parse(req, async (err, fields, files) => {
    if (err) return res.status(500).json({ error: "Upload error" });

    const token = fields.token;
    const zipFile = files.zip;

    if (!token) return res.status(400).json({ error: "Token kosong" });
    if (!zipFile) return res.status(400).json({ error: "ZIP tidak ada" });

    try {
      const zip = new AdmZip(zipFile.filepath);
      const entries = zip.getEntries();

      let vercelFiles = [];

      entries.forEach(entry => {
        if (!entry.isDirectory) {
          vercelFiles.push({
            file: entry.entryName,
            data: entry.getData().toString("base64"),
            encoding: "base64"
          });
        }
      });

      const response = await fetch("https://api.vercel.com/v13/deployments", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          name: "deploy-android",
          files: vercelFiles
        })
      });

      const result = await response.json();

      if (result.url) {
        res.json({ url: result.url });
      } else {
        res.status(500).json(result);
      }

    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
}